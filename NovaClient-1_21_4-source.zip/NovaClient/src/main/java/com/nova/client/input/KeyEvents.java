package com.nova.client.input;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Keys that were pressed since the last tick (filled by the keyboard mixin). */
public final class KeyEvents {
    private static final Set<Integer> pressed = ConcurrentHashMap.newKeySet();

    private KeyEvents() { }

    public static void press(int key) { pressed.add(key); }
    /** True if the key was pressed this tick, without using the press up. */
    public static boolean peek(int key) { return key != 0 && pressed.contains(key); }
    public static boolean consume(int key) { return key != 0 && pressed.remove(key); }
    public static void clear() { pressed.clear(); }
}
