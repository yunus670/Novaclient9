package com.nova.client.module;

import net.minecraft.client.util.InputUtil;

/** A key assigned from the ClickGUI (click it, press a key; ESC clears it). */
public final class BindSetting {
    private final String name;
    private int key;

    public BindSetting(String name, int key) {
        this.name = name;
        this.key = key;
    }

    public String getName() { return name; }
    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }

    public String getDisplayName() {
        if (key == 0) return "None";
        try {
            return InputUtil.fromKeyCode(key, 0).getLocalizedText().getString();
        } catch (Throwable t) {
            return "Key " + key;
        }
    }
}
